# backend/services/company_service.py
# Loads the Kaggle ESG snapshot CSV once at startup.
# Exposes: company list for dropdown, valid ticker set for input validation.

from pathlib import Path
import pandas as pd

BASE_DIR   = Path(__file__).parent.parent
DATA_DIR   = BASE_DIR.parent / "data"
KAGGLE_CSV = DATA_DIR / "kaggle_snapshot.csv"
ESG_CSV    = DATA_DIR / "esg_monthly_historical.csv"

# Cached in-memory after first load
_companies_list: list[dict] = []
_valid_tickers:  set[str]   = set()


def load_companies() -> None:
    """
    Called at app startup via lifespan.
    Validates both required CSVs exist, then loads and caches company list.
    Raises RuntimeError with a clear message if any file is missing.
    """
    global _companies_list, _valid_tickers

    for f in [KAGGLE_CSV, ESG_CSV]:
        if not f.exists():
            raise RuntimeError(
                f"Required data file missing: {f}\n"
                f"Run scripts/fetch_esg_history.py and download kaggle_snapshot.csv first."
            )

    df = pd.read_csv(KAGGLE_CSV)
    df["ticker"] = df["ticker"].str.upper().str.strip()

    _valid_tickers = set(df["ticker"].tolist())

    _companies_list = (
        df[["ticker", "company_name", "industry"]]
        .drop_duplicates(subset="ticker")
        .sort_values("company_name")
        .to_dict(orient="records")
    )


def get_companies_list() -> list[dict]:
    """Return cached list of { ticker, company_name, industry } dicts."""
    return _companies_list


def get_valid_tickers() -> set[str]:
    """Return cached set of valid uppercase ticker strings."""
    return _valid_tickers
