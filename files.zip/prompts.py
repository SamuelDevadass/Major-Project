# backend/config/prompts.py
# All LLM prompt templates in one place.
# Agent 4 imports these — changing prompts here requires no agent code changes.

# ── LLM CALL 1 — NEWS INTELLIGENCE EXTRACTION ────────────────────────────────

NEWS_INTELLIGENCE_PROMPT = """
You are an ESG analyst. Analyze the following news article excerpts about {company_name} ({ticker}), 
a company in the {industry} sector.

NEWS EXCERPTS:
{rag_chunks}

RECENT ESG SCORES (for context):
- Environmental Score: {e_score}
- Social Score: {s_score}
- Governance Score: {g_score}
- Total ESG Risk Score: {total_score}
(Note: Lower scores = better ESG performance in Sustainalytics methodology)

Return ONLY a valid JSON object with exactly these keys:
{{
  "positive_findings": ["<finding 1>", "<finding 2>"],
  "negative_findings": ["<finding 1>", "<finding 2>"],
  "governance_flags": ["<flag 1>"],
  "overall_news_sentiment": "<positive|mixed|negative|insufficient_data>"
}}

Rules:
- positive_findings: max 5 items, each under 30 words
- negative_findings: max 5 items, each under 30 words
- governance_flags: max 3 items, each under 20 words
- overall_news_sentiment: must be exactly one of the four options
- Return JSON only. No preamble, no explanation, no markdown.
"""

# ── LLM CALL 2 — CREDIBILITY VALIDATION ──────────────────────────────────────

CREDIBILITY_VALIDATION_PROMPT = """
You are an ESG credibility analyst. Assess whether {company_name} ({ticker})'s ESG scores 
are credible based on quantitative trends and qualitative news evidence.

YEARLY ESG SCORES (training window):
{yearly_scores}

REGRESSION ANALYSIS:
{regression_summary}

ADAPTIVE FORWARD VALIDATION:
{validation_table}

KAGGLE GRADES AND LEVELS:
{kaggle_grades}

NEWS INTELLIGENCE (from previous analysis):
- Positive Findings: {positive_findings}
- Negative Findings: {negative_findings}
- Governance Flags: {governance_flags}
- Overall Sentiment: {overall_news_sentiment}

Return ONLY a valid JSON object with exactly these keys:
{{
  "confidence_score": <integer 0-100>,
  "credibility_verdict": "<good|stable|bad|washing>",
  "supporting_evidence": ["<evidence 1>", "<evidence 2>"],
  "contradicting_evidence": ["<evidence 1>", "<evidence 2>"],
  "washing_risk": "<low|medium|high>"
}}

Rules:
- confidence_score: 0 = completely untrustworthy, 100 = fully credible
- credibility_verdict: good = scores supported by news, stable = neutral, bad = scores not supported, washing = likely greenwashing
- supporting_evidence: max 3 items
- contradicting_evidence: max 3 items
- washing_risk: low/medium/high based on gap between reported scores and news evidence
- Return JSON only. No preamble, no explanation, no markdown.
"""

# ── LLM CALL 3A — COMMENDATORY NARRATIVE (confidence >= 70) ──────────────────

NARRATIVE_COMMENDATORY_PROMPT = """
You are writing an investor ESG report section for {company_name} ({ticker}).
This company has a HIGH credibility score of {confidence_score}/100, indicating strong 
alignment between its reported ESG scores and real-world evidence.

ESG SUMMARY:
{esg_summary}

TREND: {trend_classification}
KEY POSITIVE FINDINGS: {positive_findings}
INVESTOR SIGNAL: {investor_signal}

Write a commendatory but factual 2-3 paragraph investor narrative (150-400 words).
Highlight genuine achievements, validate the trend, and explain why the signal is {investor_signal}.
Be analytical, not promotional.

Return ONLY a valid JSON object:
{{
  "narrative": "<2-3 paragraphs>",
  "key_highlights": ["<highlight 1>", "<highlight 2>", "<highlight 3>"],
  "investor_signal": "{investor_signal}"
}}

Rules:
- narrative: 150-400 words, 2-3 paragraphs
- key_highlights: exactly 3 items, each under 20 words
- investor_signal: must be exactly {investor_signal}
- Return JSON only. No preamble, no markdown.
"""

# ── LLM CALL 3B — BALANCED NARRATIVE (confidence 40-69) ──────────────────────

NARRATIVE_BALANCED_PROMPT = """
You are writing an investor ESG report section for {company_name} ({ticker}).
This company has a MODERATE credibility score of {confidence_score}/100, indicating 
partial alignment between its reported ESG scores and real-world evidence.

ESG SUMMARY:
{esg_summary}

TREND: {trend_classification}
POSITIVE FINDINGS: {positive_findings}
NEGATIVE FINDINGS: {negative_findings}
INVESTOR SIGNAL: {investor_signal}

Write a balanced, objective 2-3 paragraph investor narrative (150-400 words).
Acknowledge both strengths and concerns. Be neutral and analytical.

Return ONLY a valid JSON object:
{{
  "narrative": "<2-3 paragraphs>",
  "key_highlights": ["<highlight 1>", "<highlight 2>", "<highlight 3>"],
  "investor_signal": "{investor_signal}"
}}

Rules:
- narrative: 150-400 words, 2-3 paragraphs
- key_highlights: exactly 3 items, each under 20 words
- investor_signal: must be exactly {investor_signal}
- Return JSON only. No preamble, no markdown.
"""

# ── LLM CALL 3C — CAUTIONARY NARRATIVE (confidence < 40) ─────────────────────

NARRATIVE_CAUTIONARY_PROMPT = """
You are writing an investor ESG report section for {company_name} ({ticker}).
This company has a LOW credibility score of {confidence_score}/100, indicating 
significant gaps or contradictions between reported ESG scores and real-world evidence.

ESG SUMMARY:
{esg_summary}

TREND: {trend_classification}
NEGATIVE FINDINGS: {negative_findings}
GOVERNANCE FLAGS: {governance_flags}
WASHING RISK: {washing_risk}
INVESTOR SIGNAL: {investor_signal}

Write a cautionary but professional 2-3 paragraph investor narrative (150-400 words).
Flag specific concerns, note the credibility gap, and explain the {investor_signal} signal clearly.
Do not be alarmist — be analytical and evidence-based.

Return ONLY a valid JSON object:
{{
  "narrative": "<2-3 paragraphs>",
  "key_highlights": ["<highlight 1>", "<highlight 2>", "<highlight 3>"],
  "investor_signal": "{investor_signal}"
}}

Rules:
- narrative: 150-400 words, 2-3 paragraphs
- key_highlights: exactly 3 items, each under 20 words
- investor_signal: must be exactly {investor_signal}
- Return JSON only. No preamble, no markdown.
"""

# ── LLM CALL 4 — SYNTHESIS VERDICT ───────────────────────────────────────────

SYNTHESIS_VERDICT_PROMPT = """
You are producing the final comparative ESG verdict for an analysis of {num_companies} companies.

COMPANY SUMMARIES:
{company_summaries}

Based on ESG risk scores (lower = better), confidence scores, investor signals, 
and trend classifications, produce a final comparative verdict.

Return ONLY a valid JSON object:
{{
  "winner": "<ticker>",
  "winner_name": "<company name>",
  "rankings": ["<ticker 1>", "<ticker 2>", ...],
  "verdict_text": "<3-4 sentence comparative summary>",
  "most_improved": "<ticker>",
  "biggest_risk": "<ticker>"
}}

Rules:
- winner: ticker of company with best overall ESG profile
- rankings: ordered from best to worst ESG performance
- verdict_text: 3-4 sentences maximum, factual and comparative
- most_improved: ticker showing strongest positive trend
- biggest_risk: ticker with highest ESG risk or lowest credibility
- Return JSON only. No preamble, no markdown.
"""
