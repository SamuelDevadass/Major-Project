# backend/services/pipeline.py
# Pipeline orchestrator — calls Agents 1-5 sequentially.
# Updates job_store after each agent so frontend polling reflects real progress.
# Each agent is a stub for now — replace with real agent calls one by one.

import asyncio
from services.job_store import update_job, complete_job, fail_job


# Step → progress % mapping
STEP_PROGRESS = {
    1: 10,   # MCP Init
    2: 25,   # Data Retrieval
    3: 45,   # News RAG
    4: 62,   # LOWESS + Validation
    5: 80,   # LLM Analysis
    6: 93,   # Excel Export
}


async def run_pipeline(job_id: str, companies: list[str], year_range: list[int]) -> None:
    """
    Main pipeline entry point. Called as a FastAPI background task.
    Runs agents 1-5 in sequence, updating job_store at each step.
    """
    try:
        # ── STEP 1: MCP Orchestrator Init ─────────────────────────────────────
        update_job(job_id, 1, STEP_PROGRESS[1], "[MCP] Orchestrator initialized — session started")
        await asyncio.sleep(0)  # yield to event loop so status endpoint stays responsive

        # ── STEP 2: Agent 1 — Data Retrieval ──────────────────────────────────
        update_job(job_id, 2, STEP_PROGRESS[2], f"[AGT1] Loading ESG data for {companies} — {year_range}")
        await asyncio.sleep(0)

        # TODO: uncomment when Agent 1 is ready
        # from agents.agent1_data_retrieval import DataRetrievalAgent
        # agent1_result = await asyncio.to_thread(
        #     DataRetrievalAgent().run, companies, year_range
        # )
        agent1_result = _stub_agent1(companies, year_range)

        # ── STEP 3: Agent 2 — News RAG ────────────────────────────────────────
        update_job(job_id, 3, STEP_PROGRESS[3], f"[AGT2] Building FAISS index — {len(companies)} companies")
        await asyncio.sleep(0)

        # TODO: uncomment when Agent 2 is ready
        # from agents.agent2_news_rag import NewsRAGAgent
        # agent2_result = await asyncio.to_thread(
        #     NewsRAGAgent().run, companies, agent1_result
        # )
        agent2_result = _stub_agent2(companies)

        # ── STEP 4: Agent 3 — LOWESS + Validation ────────────────────────────
        update_job(job_id, 4, STEP_PROGRESS[4], "[AGT3] Running LOWESS smoothing + adaptive forward validation")
        await asyncio.sleep(0)

        # TODO: uncomment when Agent 3 is ready
        # from agents.agent3_validation import ValidationAgent
        # agent3_result = await asyncio.to_thread(
        #     ValidationAgent().run, agent1_result
        # )
        agent3_result = _stub_agent3(companies)

        # ── STEP 5: Agent 4 — LLM Analysis ───────────────────────────────────
        update_job(job_id, 5, STEP_PROGRESS[5],
                   f"[AGT4] Groq LLaMA3-70B — {len(companies) * 3 + 1} calls")
        await asyncio.sleep(0)

        # TODO: uncomment when Agent 4 is ready
        # from agents.agent4_llm import LLMAgent
        # agent4_result = await asyncio.to_thread(
        #     LLMAgent().run, companies, agent1_result, agent2_result, agent3_result
        # )
        agent4_result = _stub_agent4(companies)

        # ── STEP 6: Agent 5 — Excel Export ───────────────────────────────────
        update_job(job_id, 6, STEP_PROGRESS[6], "[AGT5] Generating Excel workbooks + charts")
        await asyncio.sleep(0)

        # TODO: uncomment when Agent 5 is ready
        # from agents.agent5_excel import ExcelAgent
        # agent5_result = await asyncio.to_thread(
        #     ExcelAgent().run, job_id, agent1_result, agent3_result, agent4_result
        # )
        agent5_result = _stub_agent5(job_id)

        # ── BUILD FINAL RESULTS PAYLOAD ───────────────────────────────────────
        results = _build_results(job_id, companies, year_range,
                                 agent1_result, agent2_result,
                                 agent3_result, agent4_result)

        complete_job(
            job_id,
            results=results,
            file1=agent5_result.get("file1"),
            file2=agent5_result.get("file2"),
        )

    except Exception as e:
        fail_job(job_id, str(e))
        raise


# ── RESULT ASSEMBLER ──────────────────────────────────────────────────────────

def _build_results(
    job_id: str,
    companies: list[str],
    year_range: list[int],
    agent1: dict,
    agent2: dict,
    agent3: dict,
    agent4: dict,
) -> dict:
    """Assembles the final GET /results payload from all agent outputs."""
    per_company = {}
    for ticker in companies:
        per_company[ticker] = {
            "yearly_scores":    agent1.get(ticker, {}).get("yearly_scores", {}),
            "trend":            agent3.get(ticker, {}).get("trend", {}),
            "validation_table": agent3.get(ticker, {}).get("validation_table", []),
            "news_findings":    agent2.get(ticker, {}).get("news_findings", {}),
            "credibility":      agent4.get(ticker, {}).get("credibility", {}),
            "narrative":        agent4.get(ticker, {}).get("narrative", ""),
            "key_highlights":   agent4.get(ticker, {}).get("key_highlights", []),
            "investor_signal":  agent4.get(ticker, {}).get("investor_signal", "HOLD"),
            "chart_base64":     agent3.get(ticker, {}).get("chart_base64", None),
            "kaggle_meta":      agent1.get(ticker, {}).get("kaggle_meta", {}),
        }

    return {
        "job_id":      job_id,
        "companies":   companies,
        "year_range":  year_range,
        "per_company": per_company,
        "verdict":     agent4.get("verdict", {}),
        "file_paths":  {"file1": None, "file2": None},
    }


# ── STUBS (delete these as real agents are plugged in) ────────────────────────

def _stub_agent1(companies: list[str], year_range: list[int]) -> dict:
    return {t: {"yearly_scores": {}, "kaggle_meta": {}} for t in companies}

def _stub_agent2(companies: list[str]) -> dict:
    return {t: {"news_findings": {}, "rag_chunks": []} for t in companies}

def _stub_agent3(companies: list[str]) -> dict:
    return {t: {"trend": {}, "validation_table": [], "chart_base64": None} for t in companies}

def _stub_agent4(companies: list[str]) -> dict:
    result = {
        t: {
            "credibility":     {},
            "narrative":       f"[STUB] Narrative for {t} — Agent 4 not yet connected.",
            "key_highlights":  ["Stub 1", "Stub 2", "Stub 3"],
            "investor_signal": "HOLD",
        }
        for t in companies
    }
    result["verdict"] = {
        "winner":        companies[0],
        "winner_name":   companies[0],
        "rankings":      companies,
        "verdict_text":  "[STUB] Verdict — Agent 4 not yet connected.",
        "most_improved": companies[0],
        "biggest_risk":  companies[-1],
    }
    return result

def _stub_agent5(job_id: str) -> dict:
    return {"file1": None, "file2": None}
