# backend/routers/companies.py

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from services.company_service import get_companies_list

router = APIRouter(tags=["Companies"])


@router.get("/companies", summary="Get all companies for dropdown")
def get_companies():
    """
    Returns the full list of companies from the Kaggle ESG dataset.
    Loaded once at startup, served from memory — always instant.
    Response: [{ ticker, company_name, industry }, ...]
    """
    return JSONResponse(content=get_companies_list())
